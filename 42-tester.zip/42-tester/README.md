# 42 tester

## Feature

* Test code (`main()`)
* Makefile
* Support (c00, c01, c02, c03, c04, c05, c07)
    * doesn't support **c06** and others!

## How to use

* First, you need to copy the Makefile.  
    *ex) `cp c00/Makefile [your c00 repository's root]`
* Make sure your repository directory (like `c00`, `c01` ...) is in same directory with `42-tester` directory.
    Otherwise, you must change the `MAIN_PATH` in every Makefile.
* Then, you can use `make` commands below.
    * `make norm`: norminette check
    * `make build`: compile with test code
    * `make clean`: remove executable file
    * `make exNN`: compile specific exercise (format: `exNN`)
    
    * `make`: norm && build


Copyright: [@cpm0722](https://github.com/cpm0722)
